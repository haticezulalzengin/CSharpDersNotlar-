﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nyp_hafta_2
{
    internal class Personel
    {
        string ad;

        public string Ad { get => ad; set => ad = value; }
       

        string adres;
        public string Adres { get => adres; set => adres = value; }
       

        int yas;
        public int Yas { get => yas; set => yas = value; }

    }
}
